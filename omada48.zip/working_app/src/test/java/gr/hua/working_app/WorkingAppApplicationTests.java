package gr.hua.working_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
