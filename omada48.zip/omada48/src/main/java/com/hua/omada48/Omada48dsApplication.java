package com.hua.omada48;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Omada48dsApplication {

	public static void main(String[] args) {

		System.out.println("Hello world!");
	}

}
