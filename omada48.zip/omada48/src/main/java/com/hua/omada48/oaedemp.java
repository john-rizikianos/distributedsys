package com.hua.omada48;

//oaed employee role
public class oaedemp extends user{
    public void validApp(){
        //application validation and reporting to oasa employee
    }
}
