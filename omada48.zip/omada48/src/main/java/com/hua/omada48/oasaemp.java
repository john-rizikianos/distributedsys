package com.hua.omada48;

//oasa employee role
public class oasaemp extends user{
    public void approvals(){
        
    }
}
