package com.hua.omada48;

//user parent class
public class user {
    private String username;
    private String password;

}
