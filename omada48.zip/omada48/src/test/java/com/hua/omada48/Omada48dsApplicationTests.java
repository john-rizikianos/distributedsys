package com.hua.omada48;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Omada48dsApplicationTests {

	@Test
	void contextLoads() {
	}

}
